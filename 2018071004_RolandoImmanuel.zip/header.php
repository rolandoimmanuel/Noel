<div class="jumbotron text-center" style="margin-bottom:0">
  <h1>My First Bootstrap 4 Page</h1>
  <p>Resize this responsive page to see the effect!</p> 
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="listmatakuliah.php">Mata Kuliah</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="listkategori.php">Kategori Mata Kuliah</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="listuser.php">User</a>
      </li>    
    </ul>
  </div>  
</nav>