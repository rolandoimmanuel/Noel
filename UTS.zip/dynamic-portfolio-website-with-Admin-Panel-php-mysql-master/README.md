# Dynamic Portfolio Template Using PHP/MYSQL
i converted a static webpage template into a dynamic webpage and i also designed and creatd an "Admin Panel" for manage Website Content using Bootstrap and some common technologys like html,css and javascript.

I used PHP & Mysql in backend.
sql file is included with it you have to upload it on database first.

you can check it out at
https://iportfoliomonugiri.000webhostapp.com/

admin panel
https://iportfoliomonugiri.000webhostapp.com/admin
admin id : monu@admin.com
pass: admin123

